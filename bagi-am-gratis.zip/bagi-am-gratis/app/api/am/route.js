import { NextResponse } from 'next/server';

const BASE_URL = 'https://premku.com/api/am';
const API_KEY = process.env.PREMKU_API_KEY;

export async function POST(request) {
  try {
    if (!API_KEY) {
      return NextResponse.json(
        { success: false, message: 'API Key belum dikonfigurasi di Vercel' },
        { status: 500 }
      );
    }

    const body = await request.json();
    const { action, email, qty = 1, invoice, link, ref_id } = body;

    if (!action) {
      return NextResponse.json(
        { success: false, message: 'Parameter action wajib' },
        { status: 400 }
      );
    }

    let payload = { api_key: API_KEY, action };

    if (action === 'buy_bulk') {
      payload.qty = Math.min(Math.max(parseInt(qty) || 1, 1), 5); // max 5 biar aman
      if (ref_id) payload.ref_id = ref_id;
      else payload.ref_id = `BAGI-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    }

    if (action === 'buy_single') {
      if (!email) {
        return NextResponse.json(
          { success: false, message: 'Email wajib diisi' },
          { status: 400 }
        );
      }
      payload.email = email;
    }

    if (action === 'verify_single') {
      if (!invoice || !email || !link) {
        return NextResponse.json(
          { success: false, message: 'invoice, email, dan link wajib' },
          { status: 400 }
        );
      }
      payload.invoice = invoice;
      payload.email = email;
      payload.link = link;
    }

    if (action === 'cancel_single') {
      if (!invoice) {
        return NextResponse.json(
          { success: false, message: 'invoice wajib' },
          { status: 400 }
        );
      }
      payload.invoice = invoice;
    }

    const res = await fetch(BASE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const data = await res.json();

    // Forward response dari premku
    return NextResponse.json(data, { status: res.status });
  } catch (err) {
    console.error('AM API Error:', err);
    return NextResponse.json(
      { success: false, message: 'Terjadi kesalahan server: ' + err.message },
      { status: 500 }
    );
  }
}
